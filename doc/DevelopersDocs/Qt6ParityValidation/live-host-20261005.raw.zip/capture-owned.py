import gi,time,sys,json
from pathlib import Path
gi.require_version('Gst','1.0')
from gi.repository import Gio,GLib,Gst
from PIL import Image
Gst.init(None);c=Gio.bus_get_sync(Gio.BusType.SESSION,None)
def call(path,iface,method,sig='()',args=()):return c.call_sync('org.gnome.Mutter.ScreenCast',path,iface,method,GLib.Variant(sig,args),None,Gio.DBusCallFlags.NONE,4000,None).unpack()
session=call('/org/gnome/Mutter/ScreenCast','org.gnome.Mutter.ScreenCast','CreateSession','(a{sv})',({},))[0]
stream=call(session,'org.gnome.Mutter.ScreenCast.Session','RecordMonitor','(sa{sv})',('',{'cursor-mode':GLib.Variant('u',1)}))[0]
params=call(stream,'org.freedesktop.DBus.Properties','Get','(ss)',('org.gnome.Mutter.ScreenCast.Stream','Parameters'))[0]
node=[];c.signal_subscribe(None,'org.gnome.Mutter.ScreenCast.Stream','PipeWireStreamAdded',stream,None,Gio.DBusSignalFlags.NONE,lambda c,s,o,i,n,v,d:node.append(v.unpack()[0]),None)
pipe=None
try:
 call(session,'org.gnome.Mutter.ScreenCast.Session','Start')
 end=time.monotonic()+4
 while not node and time.monotonic()<end:GLib.MainContext.default().iteration(False);time.sleep(.01)
 assert node
 pipe=Gst.parse_launch(f'pipewiresrc path={node[0]} ! videoconvert ! video/x-raw,format=RGB ! appsink name=sink sync=false max-buffers=1 drop=true');pipe.set_state(Gst.State.PLAYING)
 sample=pipe.get_by_name('sink').emit('try-pull-sample',5*Gst.SECOND);assert sample
 st=sample.get_caps().get_structure(0);w,h=st.get_value('width'),st.get_value('height');b=sample.get_buffer();ok,v=b.map(Gst.MapFlags.READ)
 image=Image.frombytes('RGB',(w,h),bytes(v.data),'raw','RGB',len(v.data)//h);b.unmap(v)
 # Crop only the owned main-window rectangle, calibrated from its visible MDI
 # boundary and monitor scale. Wayland AT-SPI SCREEN coordinates omit placement.
 sx=w/params['size'][0];sy=h/params['size'][1];x,y,cw,ch=map(int,sys.argv[2:6]);assert x>=0 and y>=0 and x+cw<=params['size'][0] and y+ch<=params['size'][1]
 image.crop((round(x*sx),round(y*sy),round((x+cw)*sx),round((y+ch)*sy))).save(sys.argv[1])
 print(json.dumps({'path':sys.argv[1],'cropLogical':[x,y,cw,ch],'pixels':[w,h]}))
finally:
 if pipe:pipe.set_state(Gst.State.NULL)
 call(session,'org.gnome.Mutter.ScreenCast.Session','Stop')
