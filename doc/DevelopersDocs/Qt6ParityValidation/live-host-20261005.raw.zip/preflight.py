from pathlib import Path
import os,subprocess,json,datetime,time
p=Path(__file__).parent
commands={'shell':['pgrep','-a','-x','gnome-shell'],'renderer':['glxinfo','-B'],'versions':['dpkg-query','-W','-f=${binary:Package} ${Version}\n','gnome-shell','libmutter-18-0','libegl-mesa0','libqt6waylandclient6'],'kernel':['uname','-r'],'user_cursor':['journalctl','--user','-n','0','--show-cursor'],'kernel_cursor':['journalctl','-k','-n','0','--show-cursor']}
r={'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'environment':{k:os.environ.get(k) for k in ['DISPLAY','WAYLAND_DISPLAY','XDG_SESSION_TYPE']}}
for label,cmd in commands.items():
 q=subprocess.run(cmd,capture_output=True,text=True,timeout=10);r[label]={'returncode':q.returncode,'stdout':q.stdout,'stderr':q.stderr}
(p/'preflight.json').write_text(json.dumps(r,indent=2)+'\n')
env=dict(os.environ)
for k in ['LIBGL_ALWAYS_SOFTWARE','GALLIUM_DRIVER','MESA_LOADER_DRIVER_OVERRIDE','QT_QPA_PLATFORMTHEME']:env.pop(k,None)
env['QT_QPA_PLATFORM']='wayland'
args=['/home/dan/GIT/GMAT-Qt/application/bin/GmatQt','--startup',str(p/'startup.txt'),'--settings-dir',str(p/'settings'),'--run','--screenshot',str(p/'screenshots/01-smoke.png'),str(p/'host.script')]
with (p/'smoke.log').open('w') as log:
 t=time.monotonic();a=subprocess.Popen(args,stdout=log,stderr=subprocess.STDOUT,env=env)
 try:status=a.wait(timeout=25)
 except subprocess.TimeoutExpired:a.terminate();status=a.wait(timeout=5)
r={'command':args,'pid':a.pid,'exit':status,'seconds':time.monotonic()-t,'environment':{'QT_QPA_PLATFORM':'wayland','softwareOverridesRemoved':True},'imageExists':(p/'screenshots/01-smoke.png').exists()}
(p/'smoke.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(r))
