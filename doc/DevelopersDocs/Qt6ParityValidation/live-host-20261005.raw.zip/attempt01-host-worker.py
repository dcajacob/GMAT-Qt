import gi,os,sys,json,time,subprocess,datetime,traceback,ctypes
from pathlib import Path
gi.require_version('Atspi','2.0');gi.require_version('Gst','1.0')
from gi.repository import Gio,GLib,Atspi,Gst
Gst.init(None)
p=Path(__file__).parent
conn=Gio.bus_get_sync(Gio.BusType.SESSION,None)
def call(dest,path,iface,method,sig='()',args=()):
 return conn.call_sync(dest,path,iface,method,GLib.Variant(sig,args),None,Gio.DBusCallFlags.NONE,4000,None).unpack()
def pump(ms=150):
 end=time.monotonic()+ms/1000
 while time.monotonic()<end:
  while GLib.MainContext.default().pending():GLib.MainContext.default().iteration(False)
  time.sleep(.01)
def shell_id():
 ids=subprocess.check_output(['pgrep','-x','gnome-shell'],text=True).split()
 return [(i,Path('/proc/'+i+'/stat').read_text().split(') ')[1].split()[19]) for i in ids]
baseline=shell_id();start=datetime.datetime.now(datetime.timezone.utc).isoformat();deadline=time.monotonic()+600
app=None;remote=None;cast=None;pipeline=None

def alive():
 if time.monotonic()>deadline:raise RuntimeError('Owned 600-second session deadline')
 if shell_id()!=baseline:raise RuntimeError('STOP: host compositor identity changed')
 if app is not None and app.poll() is not None:raise RuntimeError('Owned application exited: '+str(app.returncode))
 q=subprocess.run(['journalctl','-k','--since',start,'--no-pager','-o','cat'],capture_output=True,text=True,timeout=4)
 (p/'kernel-window.txt').write_text(q.stdout)
 import re
 if re.search(r'GPU HANG|GPU reset|Resetting (?:chip|engine)|i915.*(?:wedged|ERROR)',q.stdout,re.I):raise RuntimeError('STOP: new GPU fault diagnostic')
def application():
 desktop=Atspi.get_desktop(0)
 for i in range(desktop.get_child_count()):
  a=desktop.get_child_at_index(i)
  if a.get_process_id()==app.pid:return a
 raise RuntimeError('Owned app not registered in accessibility tree')
def tree():
 out=[]
 def walk(a,path,depth):
  if depth>13 or len(out)>1500:return
  try:
   role=a.get_role_name();name=a.get_name();states=a.get_state_set()
   visible=states.contains(Atspi.StateType.SHOWING)
   row={'path':path,'role':role,'name':name,'showing':visible}
   if visible:
    try:
     r=a.get_component_iface().get_extents(Atspi.CoordType.SCREEN);row['rect']=[r.x,r.y,r.width,r.height]
    except Exception:pass
   if states.contains(Atspi.StateType.FOCUSED):row['focused']=True
   out.append(row)
   for i in range(a.get_child_count()):walk(a.get_child_at_index(i),path+[i],depth+1)
  except Exception:pass
 walk(application(),[],0)
 return out

def inp(method,sig='()',args=()):return call('org.gnome.Mutter.RemoteDesktop',remote,'org.gnome.Mutter.RemoteDesktop.Session',method,sig,args)
def click(x,y,button=1,count=1):
 if not 0<=x<size[0] or not 0<=y<size[1]:raise ValueError('Click outside paired monitor')
 inp('NotifyPointerMotionAbsolute','(sdd)',(stream,float(x),float(y)));pump(100)
 for _ in range(count):
  inp('NotifyPointerButton','(ib)',({1:272,2:274,3:273}[button],True));pump(65)
  inp('NotifyPointerButton','(ib)',({1:272,2:274,3:273}[button],False));pump(100)
lib=ctypes.CDLL('libxkbcommon.so.0');lib.xkb_keysym_from_name.argtypes=[ctypes.c_char_p,ctypes.c_int];lib.xkb_keysym_from_name.restype=ctypes.c_uint
aliases={'CTRL':'Control_L','ALT':'Alt_L','SHIFT':'Shift_L','SUPER':'Super_L','ESC':'Escape','ENTER':'Return','TAB':'Tab','SPACE':'space','UP':'Up','DOWN':'Down','LEFT':'Left','RIGHT':'Right','HOME':'Home','END':'End','DELETE':'Delete','BACKSPACE':'BackSpace'}
def key(chord):
 syms=[lib.xkb_keysym_from_name(aliases.get(s.upper(),s).encode(),0) for s in chord.split('+')]
 if not all(syms):raise ValueError('Unknown chord '+chord)
 pressed=[]
 try:
  for k in syms:inp('NotifyKeyboardKeysym','(ub)',(k,True));pressed.append(k);pump(30)
 finally:
  for k in reversed(pressed):inp('NotifyKeyboardKeysym','(ub)',(k,False))
 pump(200)
def screenshot(label):
 global pipeline
 # Capture only the owned application's top-level screen rectangle.
 rows=tree();frames=[r for r in rows if r['role'] in ('frame','dialog') and r.get('showing') and r.get('rect')]
 if not frames:raise RuntimeError('No showing owned frame for screenshot')
 rect=frames[-1]['rect'];x,y,w,h=rect
 # Gst monitor stream pixels are physical; accessibility coordinates are logical.
 pipeline=Gst.parse_launch(f'pipewiresrc path={node[0]} do-timestamp=true ! videoconvert ! video/x-raw,format=RGB ! appsink name=sink sync=false max-buffers=1 drop=true')
 sink=pipeline.get_by_name('sink');pipeline.set_state(Gst.State.PLAYING)
 try:
  sample=sink.emit('try-pull-sample',5*Gst.SECOND)
  if sample is None:raise RuntimeError('No monitor frame in 5 seconds')
  caps=sample.get_caps().get_structure(0);fw=caps.get_value('width');fh=caps.get_value('height')
  b=sample.get_buffer();ok,info=b.map(Gst.MapFlags.READ)
  from PIL import Image
  stride=len(info.data)//fh
  img=Image.frombytes('RGB',(fw,fh),bytes(info.data),'raw','RGB',stride)
  b.unmap(info)
  scale=fw/size[0];scale_y=fh/size[1]
  crop=img.crop((max(0,round(x*scale)),max(0,round(y*scale_y)),min(fw,round((x+w)*scale)),min(fh,round((y+h)*scale_y))))
  dst=p/'screenshots'/f'{label}.png';crop.save(dst)
  return {'image':str(dst),'appRect':rect,'monitorLogicalSize':size,'capturePixelSize':[fw,fh]}
 finally:pipeline.set_state(Gst.State.NULL);pipeline=None

def emit(v):print(json.dumps(v),flush=True)
try:
 remote=call('org.gnome.Mutter.RemoteDesktop','/org/gnome/Mutter/RemoteDesktop','org.gnome.Mutter.RemoteDesktop','CreateSession')[0]
 session_id=call('org.gnome.Mutter.RemoteDesktop',remote,'org.freedesktop.DBus.Properties','Get','(ss)',('org.gnome.Mutter.RemoteDesktop.Session','SessionId'))[0]
 cast=call('org.gnome.Mutter.ScreenCast','/org/gnome/Mutter/ScreenCast','org.gnome.Mutter.ScreenCast','CreateSession','(a{sv})',({'remote-desktop-session-id':GLib.Variant('s',session_id)},))[0]
 stream=call('org.gnome.Mutter.ScreenCast',cast,'org.gnome.Mutter.ScreenCast.Session','RecordMonitor','(sa{sv})',('',{'cursor-mode':GLib.Variant('u',0)}))[0]
 params=call('org.gnome.Mutter.ScreenCast',stream,'org.freedesktop.DBus.Properties','Get','(ss)',('org.gnome.Mutter.ScreenCast.Stream','Parameters'))[0]
 size=params['size'];assert params['position']==[0,0],params
 node=[]
 conn.signal_subscribe(None,'org.gnome.Mutter.ScreenCast.Stream','PipeWireStreamAdded',stream,None,Gio.DBusSignalFlags.NONE,lambda c,s,o,i,n,v,d:node.append(v.unpack()[0]),None)
 inp('Start');pump(300)
 assert node,'No paired monitor PipeWire node'
 env=dict(os.environ)
 for k in ['LIBGL_ALWAYS_SOFTWARE','GALLIUM_DRIVER','MESA_LOADER_DRIVER_OVERRIDE']:env.pop(k,None)
 env.update(QT_QPA_PLATFORM='wayland',QT_ACCESSIBILITY='1',QT_LINUX_ACCESSIBILITY_ALWAYS_ON='1')
 log=(p/'interactive.log').open('w')
 app=subprocess.Popen(['/home/dan/GIT/GMAT-Qt/application/bin/GmatQt','--startup',str(p/'startup.txt'),'--settings-dir',str(p/'settings'),'--run',str(p/'host.script')],stdout=log,stderr=subprocess.STDOUT,env=env)
 pump(1600);alive()
 (p/'interactive-initial.json').write_text(json.dumps({'pid':app.pid,'start':start,'shell':baseline,'monitor':params,'pipewireNode':node[0],'input':'Mutter paired-monitor virtual input; no Shell introspection or security settings changed'},indent=2)+'\n')
 emit({'ready':True,'pid':app.pid,'monitor':params,'tree':tree()})
 for line in sys.stdin:
  q=json.loads(line);alive();t=time.monotonic();result=None
  if q['action']=='tree':result=tree()
  elif q['action']=='click':click(q['x'],q['y'],q.get('button',1),q.get('count',1))
  elif q['action']=='key':key(q['keys'])
  elif q['action']=='text':
   for ch in q['text']:
    symbol=ord(ch) if ord(ch)<128 else 0x01000000+ord(ch)
    inp('NotifyKeyboardKeysym','(ub)',(symbol,True));inp('NotifyKeyboardKeysym','(ub)',(symbol,False))
   pump(200)
  elif q['action']=='screenshot':result=screenshot(q['label'])
  elif q['action']=='wait':pump(min(q.get('ms',500),2000))
  elif q['action']=='quit':
   key('Alt+F4');pump(400);status=app.wait(timeout=4)
   result={'appExit':status,'shellUnchanged':shell_id()==baseline};emit(result)
   with (p/'actions.jsonl').open('a') as out:out.write(json.dumps({'request':q,'result':result})+'\n')
   break
  else:raise ValueError('Unknown action')
  pump(100);alive();r={'request':q,'result':result,'seconds':time.monotonic()-t}
  with (p/'actions.jsonl').open('a') as out:out.write(json.dumps(r)+'\n')
  emit(r)
except Exception as e:
 emit({'error':str(e),'traceback':traceback.format_exc()})
 (p/'worker-error.txt').write_text(traceback.format_exc())
finally:
 if pipeline:pipeline.set_state(Gst.State.NULL)
 if app and app.poll() is None:
  app.terminate()
  try:app.wait(timeout=4)
  except subprocess.TimeoutExpired:app.kill();app.wait()
 if remote:
  try:inp('Stop')
  except Exception:pass
 if cast:
  try:call('org.gnome.Mutter.ScreenCast',cast,'org.gnome.Mutter.ScreenCast.Session','Stop')
  except Exception:pass
 (p/'worker-final.json').write_text(json.dumps({'shellBefore':baseline,'shellAfter':shell_id(),'appExit':app.returncode if app else None,'end':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n')
