import importlib.util,json,sys
from pathlib import Path
repo=Path('/home/dan/GIT/GMAT-Qt');spec=importlib.util.spec_from_file_location('qualify',repo/'src/qtgui/tests/QualifyExamples.py');q=importlib.util.module_from_spec(spec);spec.loader.exec_module(q)
p=sys.argv[1];assert p in ['application/samples/NeedVF13ad/Ex_MarsLaunchWindowAnalysis.script','application/samples/Ex_Yukon_MarsLaunchWindowAnalysis.script']
m=json.loads((repo/'doc/DevelopersDocs/Qt6ParityValidation/shipped-examples-20261002.manifest.json').read_text());e=next(x for x in m['entries'] if x['path']==p);assert q.sha(repo/e['path'])==e['sha256']
r=q.child_stage(repo,repo/'build/example-qualification/20261005/failing-examples/windows-current-runtime',e,'run',1200)
print(json.dumps({k:r[k] for k in ['status','duration_seconds','exit_code','source_unchanged','evidence']}),flush=True)
