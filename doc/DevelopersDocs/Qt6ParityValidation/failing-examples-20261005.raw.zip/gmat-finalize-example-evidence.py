from pathlib import Path
import importlib.util,json,hashlib,collections,re,math,datetime,zipfile
repo=Path('/home/dan/GIT/GMAT-Qt');base=repo/'build/example-qualification/20261005/failing-examples';docs=repo/'doc/DevelopersDocs/Qt6ParityValidation';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
spec=importlib.util.spec_from_file_location('q',repo/'src/qtgui/tests/QualifyExamples.py');q=importlib.util.module_from_spec(spec);spec.loader.exec_module(q)
old=json.loads((docs/'shipped-examples-20261002.manifest.json').read_text());tle=json.loads((base/'tle-runs/manifest.json').read_text());oldby={e['path']:e for e in old['entries']};fresh=q.merge_previous(q.inventory(repo),old);newby={e['path']:e for e in fresh['entries']};working=json.loads((base/'disposition-working.json').read_text());rowby={r['path']:r for r in working['rows']}
for e in tle['entries']:
 if not e.get('run'):continue
 path=e['path'];assert e['run']['status']=='passed' and e['run']['source_unchanged'];dest=newby[path];dest['build']=e['build'];dest['run']=e['run'];dest.setdefault('history',[]).extend(e.get('history',[]));dest['qualification_assessment']={'disposition':'completed_historical_demonstration','limits':'Dates deliberately repaired to23Jun2020 with authenticated original archived TLE records; original current-time predictions and Dec2019 geometry not recovered. No independent orbit accuracy or native desktop qualification.'};rowby[path]['new_build']=e['build'];rowby[path]['new_run']=e['run']
verified=[]
changed_earlier_passes=[{'path':e['path'],'historical_sha256':oldby[e['path']]['sha256'],'current_sha256':e['sha256'],'limit':'Passing source changed before this task; historical results retained in history, not promoted to current-source proof. Outside the27 failing-example rows; no repeated pass.'} for e in fresh['entries'] if e['path'] not in rowby and e['sha256']!=oldby[e['path']]['sha256']]
working['changed_earlier_passes']=changed_earlier_passes
paths=['application/samples/NeedVF13ad/Ex_MarsPatchConic.script','application/samples/NeedVF13ad/Ex_MarsLaunchWindowAnalysis.script','application/samples/Ex_Yukon_MarsLaunchWindowAnalysis.script']
for path in paths:
 tree='patchconic-longer-bound' if 'PatchConic' in path else 'windows-current-runtime';p=base/tree/'scripts'/path.replace('/','__')/'run/attempt-01';r=json.loads((p/'result.json').read_text());assert r['status']=='passed' and r['source_unchanged'] and sha(repo/path)==r['source_sha256'];output=p/'output';yukon='Yukon' in path;report=output/('MarsLaunchData.txt' if yukon else 'rf.txt');vals=[list(map(float,l.split())) for l in report.read_text().splitlines()[1:] if l.strip()];expected=1 if 'PatchConic' in path else 20
 assert len(vals)==expected and all(len(v)==2 and all(math.isfinite(x) for x in v) for v in vals)
 if expected==20:assert all(abs(vals[i][0]-(27348.0637387+2*i))<1e-7 for i in range(20))
 log=(output/'GmatLog.txt').read_text();assert 'did not converge' not in log.lower() and 'failed to converge' not in log.lower();assert log.count('The Optimizer Converged!')==expected
 chunks=log.split('The Optimizer Converged!');residuals=[]
 for chunk in chunks[:-1]:
  block=chunk[chunk.rfind('Equality Constraint Variances:'):];delta=[float(x) for x in re.findall(r'Delta [^=\n]+ = ([^\s]+)',block)];assert len(delta)==6
  if not yukon:assert max(map(abs,delta))<=1
  residuals.append(delta)
 verify={'path':path,'run':r,'expected_report_rows':expected,'actual_report_rows':len(vals),'optimizer_convergence_notices':expected,'FeasibilityTolerance':1,'reported_constraint_residuals':residuals,'maximum_reported_constraint_residual':max(abs(x) for d in residuals for x in d),'report_rows':vals,'report_sha256':sha(report),'physical_residual_bound_verified':not yukon, 'limit':('Yukon printed last residuals reach22.5516413897km despite a convergence notice; accepted nominal physical feasibility is not established by these logs. ' if yukon else '')+'Reported convergence and full window counts; no independent global optimum, trajectory truth or hardware GUI qualification. Prior timeout performance difference has not been attributed.'};verified.append(verify)
 dest=newby[path];dest.setdefault('history',[]).append({'run':dest['run']});dest['run']=r;row=rowby[path];row.update(disposition='completed_current_runtime',reason='The exact unchanged source completes on the current selected Qt runtime with all original windows/settings retained; all original report rows and optimizer convergence notices are present. VF13ad last reported residuals meet FeasibilityTolerance1; Yukon physical feasibility remains unproved from its last printed residuals. The earlier runner timeout is retained, not attributed to an inherent example failure.',required_action='No further retry needed absent an affected change; preserve the current runtime and verified result.',new_run=r,output_validation={k:v for k,v in verify.items() if k!='run'})
# Require exact full current corpus source/helper identity, and preserve unchanged passing records.
for e in fresh['entries']+fresh['support']:assert sha(repo/e['path'])==e['sha256']
for path,e in oldby.items():
 if path not in rowby and newby[path]['sha256']==e['sha256']:assert newby[path].get('build')==e.get('build') and newby[path].get('run')==e.get('run')
assert len(rowby)==27
(base/'optimizer-verified-results.json').write_text(json.dumps(verified,indent=2)+'\n');q.save(base/'current-manifest.json',fresh);q.save(base/'current-summary.json',q.summary(fresh));working.update(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),summary=q.summary(fresh),optimizer_checks=verified,tle_validation=json.loads((base/'tle-verified-results.json').read_text()),TLE_checksums=json.loads((base/'tle-checksums.json').read_text()),application_changed=False,full_qualification=False,prior_failures_preserved=True)
q.save(base/'final-dispositions.json',working)
print('Final dispositions:',dict(collections.Counter(r['disposition'] for r in working['rows'])));print('Corpus',q.summary(fresh)['build'],q.summary(fresh)['run'])
